export const chartData = [
  {
    x: 1,
    y: 10,
  },
  {
    x: 2,
    y: 12,
  },
  {
    x: 3,
    y: 5,
  },
  {
    x: 4,
    y: 10,
  },
  {
    x: 5,
    y: 20,
  },
];
export const chartData2 = [
  {
    x: 1,
    y: 20,
  },
  {
    x: 2,
    y: 22,
  },
  {
    x: 3,
    y: 15,
  },
  {
    x: 4,
    y: 30,
  },
  {
    x: 5,
    y: 25,
  },
];
export const chartData3 = [
  {
    x: 1,
    y: 14,
  },
  {
    x: 2,
    y: 32,
  },
  {
    x: 3,
    y: 18,
  },
  {
    x: 4,
    y: 16,
  },
  {
    x: 5,
    y: 10,
  },
];
